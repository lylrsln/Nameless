<?php
// Display e-resources
session_start();
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>E-Resources</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
    <h1>E-Resources</h1>
    <p>List of e-resources available...</p>
</body>
</html>
