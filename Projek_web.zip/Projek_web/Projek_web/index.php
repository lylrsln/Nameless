<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="tamu.css">
    <script>
        let currentIndex = 0;
        
        function showNextImage() {
            const images = document.querySelectorAll('.carousel img');
            currentIndex = (currentIndex + 1) % images.length;
            images.forEach((img, index) => {
                img.style.transform = `translateX(-${currentIndex * 100}%)`;
            });
        }

        setInterval(showNextImage, 3000);
    </script>
</head>
<body>
    <header>
        <img src="logo.png" alt="Library Logo" class="logo">
        <div class="header-search">
            <input type="text" placeholder="Search...">
        </div>
        <div class="header-links">
            <a href="register.php">Register</a>
            <a href="login.php">Masuk</a>
        </div>
    </header>
    <nav>
        <ul>
            <li><a href="book_collection.php">Koleksi Buku</a></li>
            <li><a href="visitor_reservation.php">Reservasi Kunjungan</a></li>
            <li><a href="e_resources.php">E-Resources</a></li>
            <li><a href="literacy_agenda.php">Agenda Literasi</a></li>
            <li><a href="mobile_schedule.php">Jadwal Pusling</a></li>
            <li><a href="library_location.php">Lokasi Perpustakaan</a></li>
        </ul>
    </nav>
    <section>
        <h2>Popular Books</h2>
        <div class="carousel">
            <div class="arrow prev" onclick="movePrev()">&#10094;</div>
            <div class="book">
                <img src="Harry_potter1.png" alt="Harry Potter Book1">
                <div class="caption">Harry Potter and the Philosopher's Stone</div>
            </div>
            <div class="book">
                <img src="Harry_potter2.png" alt="Harry Potter Book2">
                <div class="caption">Harry Potter and the Chamber of Secrets</div>
            </div>
            <div class="book">
                <img src="Harry_potter3.png" alt="Harry Potter Book3">
                <div class="caption">Harry Potter and the Prisoner of Azkaban</div>
            </div>
            <div class="book">
                <img src="Harry_potter4.png" alt="Harry Potter Book4">
                <div class="caption">Harry Potter and the Goblet of Fire</div>
            </div>
            <div class="book">
                <img src="Harry_potter5.png" alt="Harry Potter Book5">
                <div class="caption">Harry Potter and the Order of the Phoenix</div>
            </div>
            <div class="arrow next" onclick="moveNext()">&#10095;</div>
        </div>
    </section>
    <footer>
        <p>&copy; 2024 Library. All rights reserved.</p>
    </footer>

    <script>
        function moveNext() {
            const images = document.querySelectorAll('.carousel img');
            currentIndex = (currentIndex + 1) % images.length;
            images.forEach((img, index) => {
                img.style.transform = `translateX(-${currentIndex * 100}%)`;
            });
        }

        function movePrev() {
            const images = document.querySelectorAll('.carousel img');
            currentIndex = (currentIndex - 1 + images.length) % images.length;
            images.forEach((img, index) => {
                img.style.transform = `translateX(-${currentIndex * 100}%)`;
            });
        }
    </script>
</body>
</html>
