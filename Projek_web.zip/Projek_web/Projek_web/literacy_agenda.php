<?php
// Display literacy agenda
session_start();
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Literacy Agenda</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
    <h1>Literacy Agenda</h1>
    <p>Upcoming literacy events...</p>
</body>
</html>
