<?php
// Display mobile schedule
session_start();
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit();
}
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mobile Schedule</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
    <h1>Mobile Library Schedule</h1>
    <p>Schedule of the mobile library...</p>
</body>
</html>
