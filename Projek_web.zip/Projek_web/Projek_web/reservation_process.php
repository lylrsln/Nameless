<?php
session_start();
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit();
}

// Validasi data yang dikirim dari formulir
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pastikan semua input terisi dengan benar
    if (empty($_POST['full_name']) || empty($_POST['occupation']) || empty($_POST['address']) || empty($_POST['phone_number']) || empty($_POST['reservation_date']) || empty($_POST['gender'])) {
        die("All fields are required.");
    }

    // Sanitasi data input
    $fullName = htmlspecialchars($_POST['full_name']);
    $occupation = htmlspecialchars($_POST['occupation']);
    $address = htmlspecialchars($_POST['address']);
    $phoneNumber = htmlspecialchars($_POST['phone_number']);
    $reservationDate = htmlspecialchars($_POST['reservation_date']);
    $gender = htmlspecialchars($_POST['gender']);

    // Lakukan penyimpanan data reservasi ke dalam database atau file (contoh menggunakan file)
    $filename = 'reservations.txt';
    $reservationData = "Nama Lengkap: $fullName\nPekerjaan: $occupation\nAlamat: $address\nNomor Telpon: $phoneNumber\nJenis Kelamin: $gender\nTanggal Kunjungan: $reservationDate\n\n";

    // Buka file untuk menulis atau tambahkan data ke file
    if (file_put_contents($filename, $reservationData, FILE_APPEND | LOCK_EX) === false) {
        die("Failed to make reservation.");
    }

    // Berhasil membuat reservasi, beri tahu pengguna
    echo "Reservation for $reservationDate is successful.";
}
?>
